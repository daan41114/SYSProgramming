using System;
using System.Drawing;

namespace Eindopdracht
{
    class Sprite
    {
        public RectangleF screenPosition;
        public Rectangle imageFrame;

    }
}



